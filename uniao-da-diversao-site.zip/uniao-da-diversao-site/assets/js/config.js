/* Personalize o site neste arquivo. Não coloque tokens, senhas ou client secrets aqui. */
window.SITE_CONFIG = {
  communityName: "União da Diversão",
  discordInvite: "https://discord.gg/SSp8fqcwg9",
  contactEmail: "", // opcional: e-mail público para receber formulários via mailto
  team: [
    { name: "Fundador(a)", role: "Fundação", avatar: "★" },
    { name: "Administrador(a)", role: "Administração", avatar: "D" },
    { name: "Moderador(a)", role: "Moderação", avatar: "M" }
  ]
};
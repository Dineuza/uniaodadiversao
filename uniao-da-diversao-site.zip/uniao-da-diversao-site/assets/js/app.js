(() => {
  const cfg = window.SITE_CONFIG || {};
  document.getElementById("year").textContent = new Date().getFullYear();
  const menu = document.querySelector(".menu-toggle"), nav = document.getElementById("nav");
  menu.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menu.setAttribute("aria-expanded", String(open));
  });
  nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));

  const icons = [["💬","Conversa"],["🎮","Jogos"],["🎉","Eventos"],["🏆","Troféu"],["⭐","Estrela"],["❤️","Coração"],["🔥","Fogo"],["🎁","Presente"],["🛡️","Proteção"],["📢","Aviso"],["🎧","Áudio"],["🌟","Brilho"],["🚀","Foguete"],["🧩","Peça"],["📌","Alfinete"],["✨","Brilhos"],["👑","Coroa"],["🤝","Parceria"]];
  const grid = document.getElementById("iconGrid"), search = document.getElementById("iconSearch");
  function renderIcons(term="") {
    grid.innerHTML = "";
    icons.filter(([emoji,name]) => (emoji+" "+name).toLowerCase().includes(term.toLowerCase())).forEach(([emoji,name]) => {
      const el=document.createElement("div"); el.className="icon-item";
      const b=document.createElement("b"), s=document.createElement("small"); b.textContent=emoji; s.textContent=name;
      el.append(b,s); grid.append(el);
    });
  }
  renderIcons(); search.addEventListener("input", e => renderIcons(e.target.value));

  function setupMailForm(id, subject, fields) {
    const form=document.getElementById(id);
    form.addEventListener("submit", e => {
      e.preventDefault();
      if (!form.reportValidity()) return;
      const data=new FormData(form);
      const body=fields.map(([key,label]) => `${label}: ${data.get(key)}`).join("\n\n");
      const email=cfg.contactEmail || "";
      if (!email) {
        form.querySelector(".form-status").textContent="Formulário validado. Para envio automático, configure contactEmail ou conecte um backend conforme o README.";
        return;
      }
      const url=`mailto:${encodeURIComponent(email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      window.location.href=url;
      form.querySelector(".form-status").textContent="Seu aplicativo de e-mail deve abrir com a mensagem pronta.";
    });
  }
  setupMailForm("reportForm","Denúncia — União da Diversão",[["user","Quem está enviando"],["reported","Usuário denunciado"],["reason","Motivo"],["details","Descrição"]]);
  setupMailForm("staffForm","Inscrição para equipe — União da Diversão",[["discord","Discord"],["area","Área"],["motivation","Motivação"]]);
})();